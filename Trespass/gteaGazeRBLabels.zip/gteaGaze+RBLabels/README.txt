The original GTEA Gaze+ labels have been manually parsed for a better text handling. 

42 classes have been produced based on the original publication (see gteaGaze+Classes.txt). 

The format of our class label is "$verb_$objects". 
In case of multiple objects, a '+' is used as separator. Whitespaces are substitued with a dash '-'.

The format of the file gteaGaze+RBLabels.csv is: $videoName,$class,$originalStart-$originalEnd$,$rbStart-$rbEnd,$rbActStart-$rbActEnd

Where:
    $videoName: name of the video as in GTEA Gaze+'s dataset
    $class: class label, formatted as explained above
    $originalStart-$originalEnd: start and end times of the object interaction, as published originally
    $rbStart-$rbEnd: start and end times of the full RB segment
    $rbActStart-$rbActEnd: start and end times of the Actional Phase of the RB segment.

Times are in milliseconds, as published originally.

Example: "Alireza_American,take_oil-container,172975-174125,172122-173538,172455-173538"

    $videoName: Alireza_American
    $class: take_oil-container (verb: take, objects: oil-container)
    $originalStart: 172975
    $originalEnd: 174125
    $rbStart: 172122
    $rbEnd: 173538
    $rbActStart: 172455
    $rbActEnd: 173538
