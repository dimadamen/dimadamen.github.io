% Created by: Dima Al Damen
% June 5th 2006

% This function is responsible for Cleaning the blob to be ready for
% allignment

function img2 = invertAndCleanBlob (img)
   img2 = im2bw (img);
   img2 = 1 - img2;
   img2 = bwmorph (img2, 'dilate', 1);
   img2 = bwmorph (img2, 'fill', Inf);
  % img2 = bwmorph (img2, 'bridge', Inf);
   img2 = bwmorph (img2, 'close', Inf);
   img2 = bwmorph (img2, 'erode', 1);
%   img2 = bwmorph (img2, 'clean', Inf);
end