function file2 = convertToSplits_f (file)
   file2 = zeros (0,5);
   count = 1;
   [t,x] = size (file);
   global minNoOfFrames;
   global maxNoOfFrames;
   i = 1;
   while (i < t)
      file (i,:)
      setNo = file(i,1);
      objNo = file(i,2);
      startFrame = file(i,3);
      endFrame = file(i,4);
      if (endFrame - startFrame < minNoOfFrames)
          i = i + 1;
          continue;
      end; 
      if (endFrame - startFrame > maxNoOfFrames)
          x = 1;
          x2 = 1;
          counter = 1;
          while (x > 0 || x2 > 0)
              newObjNo = objNo+counter;
              counter=counter+1;
              [tt,m] = find (file2(:,2) == newObjNo);
              x = size (tt,1);
              [tt2,m] = find (file(:,2) == newObjNo);
              x2 = size (tt2,1);
          end
          file2(count,:) = [setNo newObjNo startFrame startFrame+maxNoOfFrames objNo];
          count = count + 1;
          file(i,3) = startFrame+maxNoOfFrames;
      else
          i = i + 1;
          file2(count,:) = [setNo objNo startFrame endFrame objNo];
          count = count + 1;
      end;
   end;
end