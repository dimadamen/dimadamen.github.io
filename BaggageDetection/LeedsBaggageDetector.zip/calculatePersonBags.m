% Dima Damen
% A new version created on 22 Jan 2009

% Reason is to re-order the baggage output so it'd be
% <setNo> <objNo> <x> <y> <w> <h>

function bags = calculatePersonBags (beginningFileName, pBagProb, pNoBagProb, normalizedTemplate, params)

   PRange = params.Results.PRange;   

   for P=PRange
       bags = analyzePersonWithTemplatePrior6 (beginningFileName, pBagProb, pNoBagProb, normalizedTemplate, P, params);
   end;   
end