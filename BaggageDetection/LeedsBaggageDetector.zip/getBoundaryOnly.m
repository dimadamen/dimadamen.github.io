% Created by: Dima Al Damen
% June 4th 2006

% This function retrieves the boundary of a blob by erosion then
% subtraction

function imgB = getBoundaryOnly (img)
   im2 = bwmorph (img, 'erode');
   imgB = img - im2;
end