% Dima Damen
% July 10th 2007

% crops an image to be around the expected centre with width and height

% HAVEN'T BEEN TESTED PROPERLY

function cImg = centreAroundMedian (img, medianX, medianY, w, h)
  startX = medianX - round(w/2);
  startY = medianY - round(h/2);
  endX = startX + w;
  endY = startY + h;
  [oldH, oldW] = size (img);
  if (startX < 0)
      startX = 0;
  end
  if (startY < 0)
      startY = 0;
  end
  if (endX > oldW)
      endX = oldW;
  end
  if (endY > oldH)
      endY = oldH;
  end
  croppedImg = imcrop (img, [startX, startY, endX-startX-1, endY-startY-1]);
  [cH, cW] = size (croppedImg);
  if (cH < h || cW < w)
      cImg = centerImage (croppedImg, h, w);
  else
      cImg = croppedImg;
  end;
end