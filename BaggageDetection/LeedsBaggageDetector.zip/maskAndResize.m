function res = maskAndResize (img, BB, rescaleFactor)

    [h,w] = size (img);
    mask = zeros (h,w);
    mask (BB(2):BB(4), BB(1):BB(3)) = 1;
    res = img .* mask;
    
     if (rescaleFactor < 1)
         res = imresize (res, rescaleFactor, 'nearest');
     end;
end