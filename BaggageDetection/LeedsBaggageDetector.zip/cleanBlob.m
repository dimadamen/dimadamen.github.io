% Created by: Dima Al Damen
% July 2007

% This function cleans a gray scale image by filling the gaps

% input: img2 - the original image

% output: img - the filled image

% uses functions: -

function img = cleanBlob (img2)
   img2 = im2bw(img2);
   img2 = bwmorph (img2, 'dilate', 1);
   img2 = bwmorph (img2, 'fill', Inf);
   img2 = bwmorph (img2, 'close', Inf);
   img = bwmorph (img2, 'erode', 1);
end