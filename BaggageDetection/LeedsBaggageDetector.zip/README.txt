University of Leeds
School of Computing

Computer Vision Group
Leeds Baggage Detector
v 1.0 - 2009

----------------------------------

How to use �Leeds Baggage Detector�
A. Installation
     a.	Download and extract the ZIP folder (LeedsBaggageDetector.zip)
     b.	Download and extract the MATLAB Wrapper for Graph Cuts (http://www.wisdom.weizmann.ac.il/~bagon/matlab.html)
     c.	Add the path to the graph cut wrapper to the MATLAB path.

B. The Input
     a.	Foreground Segmentation of the images in the video sequence. All images should be placed in a Folder entitled �Set<No>� visible to the Leeds Baggage Detector. Files are named with the frame number (for example: 1, 2, � 7823). All formats readable by MATLAB are acceptable.

     b.	Trajectory information out of the tracker. We refer to this file as <trajectoriesFile>, and it has the following format.
<setNo>, <objNo>, <startFrame>, <endFrame>

     c.	Individual Trajectory Bounding Boxes: For each trajectory, a file with the name 
<objNo>_BB.dat should be available inside the folder �Set<No>� with the following format
<frameNo>, <minX>, <minY>, <maxX>, <maxY>

     d.	Ground-Plane Homography Data File: This file maps 2D background image to 3D world coordinates. Recall that only points on the ground-plane are required for the homography. The file should be of the following format. At least 7 points are expected.
<imageX>	�
<imageY>	
1	
<worldX>	
<worldY>	
1	
For example:
57	52	174
326	225	287
1	1	1
0	0	135
0	225	135
1	1	1

    e.	Vertical Lines Homography Data File: This file contains points representing a few lines perpendicular to the ground plane. The lines enable finding the vanishing point in the scene. The file should be of the following format:
X1	Y1	X2	Y2
�			

C. Running the Detector
    a.	Open Matlab and navigate to the Leeds Baggage Tracker Extracted folder

    b.	Run the command:
Bags = RunLeedsBaggageDetector (<trajectoriesFile>, param1, value1, param2, value2, �)
	      
Parameter			Value
�backgroundColour�		The colour of the background in the binary foreground images
				0	Black (default)
				1	White
�homography�			Name of file with ground-plane homography points
�imgtype�			Image format of the binary foreground images
				�jpg�	(default)
				�bmp�	
				�png�	
�minHeight�			Minimum accepted height of an individual in pixels (default: 80)
�verticalLines�			Name of the file with the points forming a few lines perpendicular to the ground plane
�writeIntermediateResults�	Outputs the intermediate results as images (default: false)
�minNoOfFrames�			Minimum number of frames in a single trajectory to be considered for the detection (default: 10)
�maxNoOfFrames�			Maximum number of frames before a trajectory is split. This is dependent on the value for the �split� parameter. When it is true, any trajectory longer than the specified maximum will be split into shorter sequences (default: 50)
�personHeight�			The height of the individual when analysed by the detector. Larger foreground regions are rescaled prior to the detection (default: 240)
�personWidth�			The width of the individual when analysed by the detector. Larger foreground regions are rescaled prior to the detection (default: 160)
�PRange	                        Ising model value for the MRF
�split�				A Boolean variable of whether the trajectory is considered as a whole or is split depending on the value assigned to �maxNoOfFrames� (default: false)
�topValue�			The expected percentage of non-noisy frames in the trajectory. The temporal template is made up of the topValue% frames when compared to the initial temporal template (default: 80)

c.	The output matrix would return the following information
<frameNo> <minX> <minY> <maxX> <maxY> <bagNo> <objNo>

Limitations
�	The technique works for a person tracked individually. The <trajectoryFile> input assumes the trajectories and the bounding boxes are only for individually tracked people. Groups are manually removed prior to running the code.
�	The approach has been tested for cameras mounted high above like the images below.

-----------------------------

COPYRIGHT
LICENSE.pdf included in the zipped folder