This sequence is tracked from PETS2006 - sequence 2, camera 3

Extract the contents of the zip folder into the same directory as the Leeds Baggage Detector code

Run as:
Bags = RunLeedsBaggageDetector ('set1Ex.csv');

Alternatively, you can use the following command to see the matching mechanism (stored as image files)
Bags = RunLeedsBaggageDetector ('set1Ex.csv', 'writeIntermediateResults', true);