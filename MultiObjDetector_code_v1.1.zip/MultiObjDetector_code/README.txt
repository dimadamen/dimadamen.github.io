University of Bristol
Visual Information Laboratory

Bristol's Real-Time Texture-less Multi-Object Detector: A Scalable Approach
v 1.1 - May 2013

-------------

To install: read file Install_Bristol_MOD.txt
To run: read file Run_Bristol_MOD.txt

------------

This version follows from v 1.0 with a few bug fixes to the installation process.
Special thanks for giving feedback to:
Roberto Fraile
Austin Myers

