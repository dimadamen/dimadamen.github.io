University of Bristol
Visual Information Laboratory

Bristol's Real-Time Texture-less Multi-Object Detector: A Scalable Approach
v 1.2 - Aug 2014

-------------

To install: read file Install_Bristol_MOD.txt
To run: read file Run_Bristol_MOD.txt

------------

v1.2 followed from v1.1 with changes to the method, particularly related to adaptive number of edgelets for busy edge maps

v1.1 followed from v1.0 with a few bug fixes to the installation process.
Special thanks for giving feedback to:
Roberto Fraile
Austin Myers

----- 

